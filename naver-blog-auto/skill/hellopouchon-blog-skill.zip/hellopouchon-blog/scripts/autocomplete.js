#!/usr/bin/env node
// 네이버 자동완성으로 실제 검색어 확인 (macOS·Windows·Linux 공통, Node 18+)
// 사용: node autocomplete.js "검색어1" "검색어2" ...
const qs = process.argv.slice(2);
if (!qs.length) { console.log('사용: node autocomplete.js "검색어" ...'); process.exit(1); }
(async () => {
  for (const q of qs) {
    const url = 'https://ac.search.naver.com/nx/ac?' + new URLSearchParams({
      q, con: '1', frm: 'nv', ans: '2', r_format: 'json', r_enc: 'UTF-8', r_unicode: '0',
      t_koreng: '1', run: '2', rev: '4', q_enc: 'UTF-8', st: '100',
    });
    const d = await (await fetch(url, { headers: { 'User-Agent': 'Mozilla/5.0' } })).json();
    console.log(`== ${q}`);
    console.log((d.items || []).flat().map((i) => i[0]).slice(0, 15));
  }
})().catch((e) => { console.error(e.message); process.exit(1); });
