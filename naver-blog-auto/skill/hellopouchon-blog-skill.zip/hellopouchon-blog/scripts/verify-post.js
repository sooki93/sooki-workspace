#!/usr/bin/env node
// 발행된 글 확인 (macOS·Windows·Linux 공통, Node 18+)
// 사용: node verify-post.js [logNo] [blogId]   logNo 없으면 최근 글 목록만
const [logNo, blogId = 'hellopouchon'] = process.argv.slice(2);
const UA = { headers: { 'User-Agent': 'Mozilla/5.0' } };
const get = async (u) => (await fetch(u, UA)).text();
const dec = (s) => decodeURIComponent(s.replace(/\+/g, ' '));
const strip = (h) => h.replace(/<[^>]+>/g, ' ').replace(/&quot;/g, '"').replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&#39;/g, "'").replace(/\s+/g, ' ').trim();

(async () => {
  const list = await get(`https://blog.naver.com/PostTitleListAsync.naver?blogId=${blogId}&currentPage=1&categoryNo=0&countPerPage=3`);
  console.log('== 최근 글 목록');
  for (const [, no, t] of list.matchAll(/"logNo":"(\d+)","title":"([^"]*)"/g)) console.log(no, dec(t));
  if (!logNo) return;

  const page = await get(`https://blog.naver.com/PostView.naver?blogId=${blogId}&logNo=${logNo}`);
  const m = page.slice(page.indexOf('se-main-container'));
  const text = strip(m);
  console.log(`== 글 ${logNo}`);
  console.log('사진', (m.match(/se-component se-image/g) || []).length,
    '/ 인용구', (m.match(/se-component se-quotation/g) || []).length,
    '/ 취소선', (m.match(/<strike/g) || []).length);
  console.log('소제목', [...m.matchAll(/se-component se-sectionTitle[\s\S]*?<span[^>]*>([\s\S]*?)<\/span>/g)].map((x) => strip(x[1])));
  console.log('캡션', [...m.matchAll(/se-caption[\s\S]*?<p[^>]*>([\s\S]*?)<\/p>/g)].map((x) => strip(x[1])));
  console.log('체크리스트', text.match(/□ [^□?]{0,40}\?/g) || []);

  const tags = JSON.parse(await get(`https://blog.naver.com/BlogTagListInfo.naver?blogId=${blogId}&logNoList=${logNo}&logType=mylog`));
  console.log('태그', (tags.taglist || []).map((x) => dec(x.tagName || '')));
})().catch((e) => { console.error(e.message); process.exit(1); });
